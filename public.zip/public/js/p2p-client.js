// P2P文件传输客户端 - 基于mDNS和WebRTC

class P2PClient {
    constructor() {
        this.devices = new Map();
        this.peerConnections = new Map();
        this.socket = null;
        this.isConnected = false;
        this.deviceId = null;
        
        // WebRTC配置
        this.rtcConfig = {
            iceServers: [
                // 免费STUN服务器
                { urls: 'stun:stun.l.google.com:19302' },
                { urls: 'stun:stun1.l.google.com:19302' },
                { urls: 'stun:stun2.l.google.com:19302' },
                { urls: 'stun:stun3.l.google.com:19302' },
                { urls: 'stun:stun4.l.google.com:19302' }
            ]
        };
        
        this.init();
    }
    
    // 初始化
    async init() {
        // 尝试mDNS发现
        await this.discoverDevices();
        
        // 连接到WebSocket服务器（跨网使用）
        this.connectWebSocket();
    }
    
    // mDNS设备发现（浏览器端通过WebRTC实现）
    async discoverDevices() {
        try {
            // 浏览器端mDNS实现（使用WebRTC的RTCPeerConnection和getStats）
            console.log('正在搜索局域网设备...');
            
            // 尝试使用WebRTC的Network Information API
            if ('connection' in navigator) {
                console.log('网络信息:', navigator.connection);
            }
            
            // 实际实现中，浏览器端无法直接使用mDNS，需要通过WebSocket服务器或其他方式
            // 这里我们使用WebSocket服务器作为后备方案
        } catch (error) {
            console.error('mDNS发现失败:', error);
        }
    }
    
    // 连接到WebSocket服务器
    connectWebSocket() {
        // 使用本地WebSocket服务器，生产环境可以使用免费的公共WebSocket服务
        const wsUrl = window.location.protocol === 'https:' ? 
            `wss://${window.location.host}` : 
            `ws://${window.location.host}`;
        
        this.socket = new WebSocket(wsUrl);
        
        this.socket.onopen = () => {
            console.log('WebSocket连接已建立');
            this.isConnected = true;
        };
        
        this.socket.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                this.handleWebSocketMessage(data);
            } catch (error) {
                console.error('WebSocket消息解析错误:', error);
            }
        };
        
        this.socket.onclose = () => {
            console.log('WebSocket连接已关闭');
            this.isConnected = false;
            // 尝试重连
            setTimeout(() => this.connectWebSocket(), 5000);
        };
        
        this.socket.onerror = (error) => {
            console.error('WebSocket错误:', error);
        };
    }
    
    // 处理WebSocket消息
    handleWebSocketMessage(data) {
        switch (data.type) {
            case 'devices':
                // 更新设备列表
                this.devices.clear();
                data.devices.forEach((deviceId) => {
                    this.devices.set(deviceId, {
                        id: deviceId,
                        name: `设备 ${deviceId.substring(0, 5)}`
                    });
                });
                this.onDevicesUpdated();
                break;
                
            case 'device-joined':
                // 新设备加入
                this.devices.set(data.deviceId, {
                    id: data.deviceId,
                    name: `设备 ${data.deviceId.substring(0, 5)}`
                });
                this.onDevicesUpdated();
                break;
                
            case 'device-left':
                // 设备离开
                this.devices.delete(data.deviceId);
                this.onDevicesUpdated();
                break;
                
            case 'signal':
                // 处理信令
                this.handleSignal(data.from, data.signal);
                break;
        }
    }
    
    // 处理信令
    async handleSignal(from, signal) {
        let pc = this.peerConnections.get(from);
        
        if (!pc) {
            // 创建新的PeerConnection
            pc = this.createPeerConnection(from);
        }
        
        try {
            if (signal.type === 'offer') {
                await pc.setRemoteDescription(new RTCSessionDescription(signal));
                const answer = await pc.createAnswer();
                await pc.setLocalDescription(answer);
                
                // 发送answer
                this.sendSignal(from, answer);
            } else if (signal.type === 'answer') {
                await pc.setRemoteDescription(new RTCSessionDescription(signal));
            } else if (signal.type === 'candidate') {
                await pc.addIceCandidate(new RTCIceCandidate(signal));
            }
        } catch (error) {
            console.error('信令处理错误:', error);
        }
    }
    
    // 创建PeerConnection
    createPeerConnection(deviceId) {
        const pc = new RTCPeerConnection(this.rtcConfig);
        
        // 创建数据通道
        const dataChannel = pc.createDataChannel('fileTransfer', {
            ordered: true, // 确保数据包有序到达
            maxRetransmits: 10 // 最大重传次数
        });
        
        this.setupDataChannel(dataChannel, deviceId);
        this.setupPeerConnection(pc, deviceId);
        
        this.peerConnections.set(deviceId, pc);
        return pc;
    }
    
    // 设置数据通道
    setupDataChannel(channel, deviceId) {
        channel.onopen = () => {
            console.log(`与设备 ${deviceId} 的数据通道已打开`);
            this.onConnectionEstablished(deviceId);
        };
        
        channel.onmessage = (event) => {
            this.handleDataMessage(deviceId, event.data);
        };
        
        channel.onclose = () => {
            console.log(`与设备 ${deviceId} 的数据通道已关闭`);
            this.onConnectionClosed(deviceId);
        };
        
        channel.onerror = (error) => {
            console.error(`数据通道错误 (${deviceId}):`, error);
        };
    }
    
    // 设置PeerConnection
    setupPeerConnection(pc, deviceId) {
        pc.onicecandidate = (event) => {
            if (event.candidate) {
                this.sendSignal(deviceId, event.candidate);
            }
        };
        
        pc.ondatachannel = (event) => {
            this.setupDataChannel(event.channel, deviceId);
        };
        
        pc.onconnectionstatechange = () => {
            console.log(`连接状态 (${deviceId}):`, pc.connectionState);
            
            if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected') {
                this.peerConnections.delete(deviceId);
                this.onConnectionClosed(deviceId);
            }
        };
    }
    
    // 发送信令
    sendSignal(target, signal) {
        if (this.isConnected) {
            this.socket.send(JSON.stringify({
                type: 'signal',
                target: target,
                signal: signal
            }));
        }
    }
    
    // 连接到设备
    async connectToDevice(deviceId) {
        console.log(`正在连接到设备: ${deviceId}`);
        
        let pc = this.peerConnections.get(deviceId);
        if (!pc) {
            pc = this.createPeerConnection(deviceId);
        }
        
        // 创建offer
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        
        // 发送offer
        this.sendSignal(deviceId, offer);
    }
    
    // 发送文件
    sendFile(deviceId, file) {
        const pc = this.peerConnections.get(deviceId);
        if (!pc) {
            console.error('未连接到该设备');
            return;
        }
        
        // 获取数据通道
        const dataChannel = pc.createDataChannel('fileTransfer');
        
        if (dataChannel.readyState === 'open') {
            this._sendFile(dataChannel, file);
        } else {
            dataChannel.onopen = () => {
                this._sendFile(dataChannel, file);
            };
        }
    }
    
    // 实际发送文件
    _sendFile(dataChannel, file) {
        const CHUNK_SIZE = 16384; // 16KB
        let offset = 0;
        
        // 发送文件元数据
        const metadata = {
            type: 'file',
            name: file.name,
            size: file.size
        };
        dataChannel.send(JSON.stringify(metadata));
        
        // 读取并发送文件
        const reader = new FileReader();
        
        const readNextChunk = () => {
            const chunk = file.slice(offset, offset + CHUNK_SIZE);
            reader.readAsArrayBuffer(chunk);
        };
        
        reader.onload = (e) => {
            const buffer = e.target.result;
            dataChannel.send(buffer);
            
            offset += buffer.byteLength;
            
            // 更新进度
            const progress = Math.round((offset / file.size) * 100);
            this.onFileProgress(file.name, progress);
            
            if (offset < file.size) {
                readNextChunk();
            } else {
                this.onFileSent(file.name);
            }
        };
        
        readNextChunk();
    }
    
    // 处理数据消息
    handleDataMessage(deviceId, data) {
        if (typeof data === 'string') {
            // 处理元数据
            try {
                const metadata = JSON.parse(data);
                if (metadata.type === 'file') {
                    this.currentFile = {
                        name: metadata.name,
                        size: metadata.size,
                        data: []
                    };
                    this.receivedSize = 0;
                    this.onFileStart(metadata.name);
                }
            } catch (error) {
                console.error('元数据解析错误:', error);
            }
        } else {
            // 处理文件数据
            if (this.currentFile) {
                this.currentFile.data.push(data);
                this.receivedSize += data.byteLength;
                
                const progress = Math.round((this.receivedSize / this.currentFile.size) * 100);
                this.onFileProgress(this.currentFile.name, progress);
                
                if (this.receivedSize >= this.currentFile.size) {
                    // 文件接收完成
                    const file = this.currentFile;
                    this.currentFile = null;
                    this.receivedSize = 0;
                    
                    this.onFileReceived(file);
                }
            }
        }
    }
    
    // 设备列表更新回调
    onDevicesUpdated() {
        // 由外部实现
        console.log('设备列表已更新:', Array.from(this.devices.keys()));
    }
    
    // 连接建立回调
    onConnectionEstablished(deviceId) {
        // 由外部实现
        console.log('连接已建立:', deviceId);
    }
    
    // 连接关闭回调
    onConnectionClosed(deviceId) {
        // 由外部实现
        console.log('连接已关闭:', deviceId);
    }
    
    // 文件开始接收回调
    onFileStart(fileName) {
        // 由外部实现
        console.log('开始接收文件:', fileName);
    }
    
    // 文件进度回调
    onFileProgress(fileName, progress) {
        // 由外部实现
        console.log(`文件进度 ${fileName}: ${progress}%`);
    }
    
    // 文件发送完成回调
    onFileSent(fileName) {
        // 由外部实现
        console.log('文件发送完成:', fileName);
    }
    
    // 文件接收完成回调
    onFileReceived(file) {
        // 由外部实现
        console.log('文件接收完成:', file.name);
        
        // 创建Blob并下载
        const blob = new Blob(file.data);
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = file.name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
    
    // 获取设备列表
    getDevices() {
        return Array.from(this.devices.values());
    }
}

// 导出类
if (typeof module !== 'undefined' && module.exports) {
    module.exports = P2PClient;
} else {
    window.P2PClient = P2PClient;
}