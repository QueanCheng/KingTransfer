// MemFire Cloud 云函数 - 信令服务器
export default async function handler(event, context) {
  const { method, body } = event;
  
  if (method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
      },
      body: ''
    };
  }
  
  if (method === 'POST') {
    try {
      const data = JSON.parse(body);
      const { action, roomId, peerId, signal } = data;
      
      // 这里可以根据需要扩展，例如使用数据库存储房间信息
      // 目前简单实现，直接返回成功
      
      return {
        statusCode: 200,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          success: true,
          message: '信令转发成功',
          data: {
            action,
            roomId,
            peerId,
            signal
          }
        })
      };
    } catch (error) {
      return {
        statusCode: 400,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          success: false,
          message: '请求格式错误',
          error: error.message
        })
      };
    }
  }
  
  return {
    statusCode: 405,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Allow': 'POST, OPTIONS'
    },
    body: JSON.stringify({
      success: false,
      message: '方法不允许'
    })
  };
}